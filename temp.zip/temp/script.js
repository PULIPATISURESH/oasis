// Function to convert Celsius to Fahrenheit
function convertToFar() {
    var celsius = document.getElementById("celsius").value;

    if (celsius === "" || isNaN(celsius)) {
        alert("Please enter a valid temperature in Celsius");
        return;
    }

    var fahrenheit = (parseFloat(celsius) * 9/5) + 32;

    document.getElementById("result").innerHTML = celsius + " Celsius is " + fahrenheit.toFixed(2) + " Fahrenheit";
}

// Function to convert Fahrenheit to Celsius
function convertToCel() {
    var fahrenheit = document.getElementById("fahrenheit").value;

    if (fahrenheit === "" || isNaN(fahrenheit)) {
        alert("Please enter a valid temperature in Fahrenheit");
        return;
    }

    var celsius = (parseFloat(fahrenheit) - 32) * 5/9;

    document.getElementById("result").innerHTML = fahrenheit + " Fahrenheit is " + celsius.toFixed(2) + " Celsius";
}

// Add event listeners to trigger conversions on input change
document.getElementById("celsius").addEventListener("input", convertToFar);
document.getElementById("fahrenheit").addEventListener("input", convertToCel);
